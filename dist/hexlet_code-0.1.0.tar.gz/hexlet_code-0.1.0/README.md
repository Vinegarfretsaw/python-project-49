### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vinegarfretsaw/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vinegarfretsaw/python-project-49/actions)


### Code Climate Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/c188435b5a1beeb34b46/maintainability)](https://codeclimate.com/github/Vinegarfretsaw/python-project-49/maintainability)
