Welcome to the Brain Games!
### Asciinema "Start of Brain Games":
[![asciicast](https://asciinema.org/a/558743.svg)](https://asciinema.org/a/558743)

### Asciinema "Win of the brain-even game":
[![asciicast](https://asciinema.org/a/558744.svg)](https://asciinema.org/a/558744)


### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vinegarfretsaw/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vinegarfretsaw/python-project-49/actions)

### Code Climate Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/c188435b5a1beeb34b46/maintainability)](https://codeclimate.com/github/Vinegarfretsaw/python-project-49/maintainability)