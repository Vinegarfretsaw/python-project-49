# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': 'Welcome to the Brain Games!\n### Asciinema "Start of Brain Games":\n[![asciicast](https://asciinema.org/a/558743.svg)](https://asciinema.org/a/558743)\n\n### Asciinema "Win of the brain-even game":\n[![asciicast](https://asciinema.org/a/558744.svg)](https://asciinema.org/a/558744)\n\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Vinegarfretsaw/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vinegarfretsaw/python-project-49/actions)\n\n### Code Climate Badge:\n[![Maintainability](https://api.codeclimate.com/v1/badges/c188435b5a1beeb34b46/maintainability)](https://codeclimate.com/github/Vinegarfretsaw/python-project-49/maintainability)',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9.6,<4.0.0',
}


setup(**setup_kwargs)
