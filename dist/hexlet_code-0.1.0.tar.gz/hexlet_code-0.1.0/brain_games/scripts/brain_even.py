#!/usr/bin/env python3


from brain_games import game_brain_even


def main():
    game_brain_even()


if __name__ == '__main__':
    main()
