import prompt


def start_game():
    print("Welcome to the Brain Games!")
    name = prompt.string("May I have your name? ")
    print(f'Hello, {name}!')
    return name


def start():
    print("Answer «yes» if the number is even, otherwise answer «no».")
